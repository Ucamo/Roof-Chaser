﻿using UnityEngine;
using System.Collections;

public class GameJoltAPI : MonoBehaviour {
	
	public int gameID;
	public string privateKey;
	public string userName;
	public string userToken;
	
	
	
	void Awake () {
		
		
		
		DontDestroyOnLoad ( gameObject );
		GJAPI.Init ( gameID, privateKey );
		GJAPIHelper.Users.GetFromWeb (OnGetFromWeb);//Get Information
		GJAPI.Users.Verify ( userName, userToken );
	}
	
	void Start ()
		
	{
        try
        {
            //Application.ExternalCall("GJAPI_AuthUser", gameObject.name, "MyMethodToCall");
        }
        catch { }
	}

    void OnEnable()
    {
        GJAPI.Users.VerifyCallback += OnVerifyUser;
    }

    void OnDisable()
    {
        // Use this if you use the API v1.2.x
        GJAPI.Users.VerifyCallback -= OnVerifyUser;

        // Use this if you use the API v1.3.x
        if (GJAPI.Instance != null)
        {
            GJAPI.Users.VerifyCallback -= OnVerifyUser;
        }
    }

	
	void OnVerifyUser ( bool success ) {
		if ( success ) {
			Debug.Log ( "Yepee!" );
			uint puntos = (uint)Runner.distanceTraveled;
			
			GJAPI.Scores.Add(puntos.ToString(),puntos,37171,"");

		}
		else {
			Debug.Log ( "Um... Something went wrong." );
		}
	}
	public void MyMethodToCall ( string response )
	{
		Debug.Log ("entro");
		string[] splittedResponse = response.Split ( ':' );
		userName = splittedResponse [0];
		userToken = splittedResponse [1];
		GJAPI.Users.Verify ( userName, userToken );
		// Do whatever you want with it.
	}
	
	void OnGetFromWeb (string name, string token)
		
	{
		
		Debug.Log (name + "@" + token);
		
		userName = name;
		
		userToken = token;
		
		GJAPI.Users.Verify ( userName, userToken );
		
	}
}