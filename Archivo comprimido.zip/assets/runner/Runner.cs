﻿using UnityEngine;

public class Runner : MonoBehaviour {
	
	public static float distanceTraveled;
	public float acceleration;
	private bool touchingPlatform;

	public Vector3 boostVelocity, jumpVelocity;
	public float gameOverY;
	private Vector3 startPosition;
	private static int boosts;
	public GameObject robot;
	private Object gjapiman;

	private string userName;
	private string userToken;

	void Start(){
		//Application.ExternalCall ( "GJAPI_AuthUser", gameObject.name, "MyMethodToCall" );
		GameEventManager.GameStart += GameStart;
		GameEventManager.GameOver += GameOver;
		startPosition = transform.localPosition;
		GetComponent<Renderer>().enabled = false;
		GetComponent<Rigidbody>().isKinematic = true;
		enabled = false;

		GJAPI.Init ( 35714, "9fc6fad05cc47440fdfaa25e123fff72");
		GJAPIHelper.Users.GetFromWeb (OnGetFromWeb);//Get Information
		GJAPI.Users.Verify ( userName, userToken );

	}

	public void MyMethodToCall ( string response )
	{
		Debug.Log ("entro");
		string[] splittedResponse = response.Split ( ':' );
		userName = splittedResponse [0];
		userToken = splittedResponse [1];
		GJAPI.Users.Verify ( userName, userToken );
		// Do whatever you want with it.
	}

	void OnGetFromWeb (string name, string token)
		
	{
		
		Debug.Log (name + "@" + token);
		
		userName = name;
		
		userToken = token;
		
		GJAPI.Users.Verify ( userName, userToken );
		
	}

	private void GameStart(){
		boosts = 0;
		GUIManager.SetBoosts (boosts);
		distanceTraveled = 0f;
		GUIManager.SetDistance (distanceTraveled);
		transform.localPosition = startPosition;
		GetComponent<Renderer>().enabled = false;
		GetComponent<Rigidbody>().isKinematic = false;
		enabled = true;
		boosts=2;
		GUIManager.SetBoosts(boosts);
		robot.SetActive(true);
		DestroyObject (gjapiman);

	}

	private void GameOver(){
		GetComponent<Renderer>().enabled = false;
		GetComponent<Rigidbody>().isKinematic = true;
		enabled = false;
		robot.SetActive(false);
		 gjapiman = Instantiate(Resources.Load("GameJoltApiManager"));
	}

	
	void Update () {
		if (touchingPlatform) {

			robot.GetComponent<Animation>().Play("ArmatureAction");
			boosts=2;
			GUIManager.SetBoosts(boosts);
		}
		if(Input.GetButtonDown("Jump")){
			// Jump animation
			if(touchingPlatform){
			}
			else{

				robot.GetComponent<Animation>().Play("ArmatureAction");
			}
			if(touchingPlatform){
				GetComponent<Rigidbody>().AddForce(jumpVelocity, ForceMode.VelocityChange);
				touchingPlatform = false;

			}
			else if(boosts > 0){
				GetComponent<Rigidbody>().AddForce(boostVelocity, ForceMode.VelocityChange);
				boosts -= 1;
				GUIManager.SetBoosts(boosts);
			}
		}
		distanceTraveled = transform.localPosition.x;
		GUIManager.SetDistance (distanceTraveled);

		if(transform.localPosition.y < gameOverY){
			GameEventManager.TriggerGameOver();
		}

		//add Trophies
		if (distanceTraveled >= 100 && distanceTraveled <= 101) 
		{
			GJAPI.Trophies.Add(11881);
		}
		if (distanceTraveled >= 300 && distanceTraveled <= 301) 
		{
			GJAPI.Trophies.Add(11882);
		}
		if (distanceTraveled >= 500 && distanceTraveled <= 501) 
		{
			GJAPI.Trophies.Add(11883);
		}
		if (distanceTraveled >= 1000 && distanceTraveled <= 1001) 
		{
			GJAPI.Trophies.Add(11884);
		}
		if (distanceTraveled >= 1101 && distanceTraveled <= 1102) 
		{
			GJAPI.Trophies.Add(11885);
		}
		if (distanceTraveled >= 2000 && distanceTraveled <= 2001) 
		{
			GJAPI.Trophies.Add(11886);
		}
		if (distanceTraveled >= 4000 && distanceTraveled <= 4001) 
		{
			GJAPI.Trophies.Add(11887);
		}
		if (distanceTraveled >= 6000 && distanceTraveled <= 6001) 
		{
			GJAPI.Trophies.Add(11888);
		}
		if (distanceTraveled >= 10000 && distanceTraveled <= 10001) 
		{
			GJAPI.Trophies.Add(11889);
		}
		if (distanceTraveled >= 20000 && distanceTraveled <= 20001) 
		{
			GJAPI.Trophies.Add(11890);
		}
		if (distanceTraveled >= 50000 && distanceTraveled <= 50001) 
		{
			GJAPI.Trophies.Add(11891);
		}
	}
	
	void FixedUpdate () {
		if(touchingPlatform){
			GetComponent<Rigidbody>().AddForce(acceleration, 0f, 0f, ForceMode.Acceleration);
		}
	}
	
	void OnCollisionEnter () {
		//robot.GetComponent<Animation>().Play("landingStill");
		touchingPlatform = true;
	}
	
	void OnCollisionExit () {
		//robot.GetComponent<Animation>().Play("JumpStill");
		touchingPlatform = false;
	}

	void OnTriggerEnter () {
		Runner.AddBoost();
		gameObject.SetActive(false);
	}

	public static void AddBoost () {
		boosts += 1;
		GUIManager.SetBoosts (boosts);
	}
}
