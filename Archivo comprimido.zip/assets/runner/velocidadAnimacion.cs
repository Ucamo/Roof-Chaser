﻿using UnityEngine;
using System.Collections;

public class velocidadAnimacion : MonoBehaviour {

	// Use this for initialization
	void Start () {
		GetComponent<Animation>()["ArmatureAction"].speed = 3f;
		GetComponent<Animation>()["brinco"].speed = 3f;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
}
