﻿using UnityEngine;
using System.Collections;

public class GUIManager : MonoBehaviour {

	public GUIText gameOverText,instructionsText,runnerText,boostText,distanceText,infoBoostText,infoDistanceText;
	public static GUIManager instance;

	void Start(){
		instance = this;
		GameEventManager.GameStart += GameStart;
		GameEventManager.GameOver += GameOver;
		gameOverText.enabled = false;
		infoBoostText.enabled = false;
		infoDistanceText.enabled = false;
	}

	void Update(){
		if (Input.GetButton ("Jump")) {
			GameEventManager.TriggerGameStart();
		}
	}

	private void GameOver(){
		gameOverText.enabled = true;
		instructionsText.enabled = true;

		enabled = true;
	}

	private void GameStart(){
		gameOverText.enabled = false;
		instructionsText.enabled = false;
		runnerText.enabled = false;
		infoBoostText.enabled = true;
		infoDistanceText.enabled = true;
		enabled = false;
	}

	public static void SetBoosts(int boosts)
	{
		instance.boostText.text = boosts.ToString ();
	}

	public static void SetDistance(float distance)
	{
		instance.distanceText.text = distance.ToString ("f0");
	}
}
